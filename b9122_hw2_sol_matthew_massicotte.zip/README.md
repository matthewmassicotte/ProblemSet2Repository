# ProblemSet2Repository
 repo for problem set 2
 
 Created by Matthew Massicotte
 
This repository contains three code files.  webcrawler.py is the webcrawler created in class.

PS2_webcrawler_charges.py crawls the SEC press release page looking for articles that contain the word "charges" then printing the text of the article

PS2_webcrawler_covid.py crawls the federal reserve press release page and shares urls to pages that contain the word "covid"

